"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { MessageCircle, Shield, MapPin, ChevronRight, AlertCircle } from "lucide-react"

const promptSuggestions = [
  "Build my onboarding profile",
  "Start triage process",
  "How do I register with a GP?",
  "What NHS services am I eligible for?",
]

const mockChatExchanges = [
  {
    role: "assistant" as const,
    message: "Hi! I can help you navigate NHS services. What would you like to know?",
  },
  {
    role: "user" as const,
    message: "How do I register with a GP near campus?",
  },
  {
    role: "assistant" as const,
    message:
      "Great question! First, you'll need to find a GP practice near LBS. You can use the NHS service search tool. Most practices let you register online or in person. You'll need proof of address and ID. Would you like more details on any of these steps?",
  },
]

const onboardingSteps = [
  { id: 1, label: "Student status", active: true },
  { id: 2, label: "UK residency", active: false },
  { id: 3, label: "Health background", active: false },
  { id: 4, label: "Current GP", active: false },
  { id: 5, label: "Preferences", active: false },
  { id: 6, label: "Confirmation", active: false },
]

const triageFlow = [
  { step: "Severity check", status: "What symptoms are you experiencing?" },
  { step: "Red flags", status: "Any chest pain or difficulty breathing?" },
  { step: "Recommendation", status: "Based on your answers, I recommend contacting your GP within 24 hours." },
]

const usefulLinks = [
  { title: "Find a GP", url: "https://www.nhs.uk/service-search/find-a-gp" },
  { title: "Register with a GP", url: "https://www.nhs.uk/nhs-services/gps/how-to-register-with-a-gp-surgery/" },
  { title: "Use NHS 111 online", url: "https://111.nhs.uk/" },
  { title: "NHS services guide", url: "https://www.nhs.uk/using-the-nhs/nhs-services/" },
  { title: "LBS health and wellbeing", url: "https://www.london.edu/masters-experience/student-support" },
  {
    title: "LBS mental wellbeing support",
    url: "https://www.london.edu/masters-experience/student-support/mental-health",
  },
]

export default function Home() {
  const [chatInput, setUserInput] = useState("")
  const [showThinking, setShowThinking] = useState(false)

  const handleSendMessage = () => {
    if (chatInput.trim()) {
      setShowThinking(true)
      setTimeout(() => setShowThinking(false), 2000)
      setUserInput("")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy via-navy to-[#1a2942]">
      {/* Background pattern */}
      <div className="fixed inset-0 opacity-10">
        <div className="absolute top-20 right-20 w-96 h-96 bg-teal rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-coral rounded-full blur-3xl"></div>
      </div>

      <div className="relative">
        {/* Hero Section */}
        <section className="container mx-auto px-4 pt-16 pb-20 md:pt-24 md:pb-32">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="inline-flex items-center gap-2 bg-sand/10 border border-sand/30 rounded-full px-4 py-2 mb-6">
              <span className="text-sand text-sm font-medium">Built for LBS students</span>
            </div>

            <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-bold text-sand mb-6 text-balance">
              Navigate NHS services with confidence
            </h1>

            <p className="text-xl md:text-2xl text-sand/80 mb-10 leading-relaxed text-pretty">
              Fast, friendly guidance for GP registration, triage, eligibility, and next steps across UK care pathways.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-teal hover:bg-teal/90 text-white font-semibold px-8 py-6 text-lg">
                <MessageCircle className="mr-2 h-5 w-5" />
                Start a chat
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-sand/30 text-sand hover:bg-sand/10 font-semibold px-8 py-6 text-lg bg-transparent"
              >
                See how it works
              </Button>
            </div>
          </div>
        </section>

        {/* How I Can Help Card */}
        <section className="container mx-auto px-4 pb-16">
          <Card className="max-w-4xl mx-auto bg-sand/95 border-sand/50 p-8 md:p-10 shadow-2xl backdrop-blur-sm animate-fade-in delay-100">
            <h2 className="font-serif text-3xl font-bold text-navy mb-6">How I can help</h2>
            <div className="prose prose-lg max-w-none text-navy/90 leading-relaxed">
              <p className="mb-4">
                Hi there, welcome to the LBS Community! My name is Evi - Your LBS Healthcare Companion.
              </p>
              <p className="mb-4">
                Now that you've made it to London, I'm sure you have a lot of questions about navigating the NHS and LBS
                wellbeing services.
              </p>
              <p className="mb-4">Feel free to start with one of the examples below to get you oriented.</p>
              <ul className="space-y-2 mb-4">
                <li>Better understand when and how to use NHS services (GP, NHS 111, A&E, and more!)</li>
                <li>Locate mental health or wellbeing support</li>
                <li>Get more information about preventative-care guidance</li>
              </ul>
              <p className="text-teal font-semibold">
                Or, type "onboarding" at any time, and I will ask a few brief questions to get to know you better.
              </p>
            </div>
          </Card>
        </section>

        {/* Prompt Suggestions */}
        <section className="container mx-auto px-4 pb-16">
          <div className="max-w-4xl mx-auto">
            <h3 className="font-serif text-2xl font-bold text-sand mb-6 text-center">Quick start prompts</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {promptSuggestions.map((prompt, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  className="border-sand/30 text-sand hover:bg-sand/10 hover:border-sand/50 justify-start text-left h-auto py-4 px-6 animate-fade-in bg-transparent"
                  style={{ animationDelay: `${idx * 100 + 200}ms` }}
                >
                  <ChevronRight className="mr-2 h-4 w-4 flex-shrink-0 text-teal" />
                  <span className="text-base">{prompt}</span>
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Chat Panel */}
        <section className="container mx-auto px-4 pb-16">
          <div className="max-w-4xl mx-auto">
            <h3 className="font-serif text-2xl font-bold text-sand mb-6 text-center">Chat preview</h3>
            <Card className="bg-sand/95 border-sand/50 p-6 shadow-2xl backdrop-blur-sm">
              <div className="space-y-4 mb-6 min-h-[300px]">
                {mockChatExchanges.map((exchange, idx) => (
                  <div
                    key={idx}
                    className={`flex ${exchange.role === "user" ? "justify-end" : "justify-start"} animate-fade-in`}
                    style={{ animationDelay: `${idx * 150}ms` }}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-5 py-3 ${
                        exchange.role === "user" ? "bg-teal text-white" : "bg-navy/10 text-navy border border-navy/20"
                      }`}
                    >
                      <p className="text-sm leading-relaxed">{exchange.message}</p>
                    </div>
                  </div>
                ))}
                {showThinking && (
                  <div className="flex justify-start">
                    <div className="bg-navy/10 text-navy border border-navy/20 rounded-2xl px-5 py-3">
                      <p className="text-sm italic">Thinking...</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="Ask a question or type 'onboarding'…"
                  className="flex-1 px-4 py-3 rounded-lg border-2 border-navy/20 focus:border-teal focus:outline-none bg-white text-navy placeholder:text-navy/50"
                />
                <Button onClick={handleSendMessage} className="bg-teal hover:bg-teal/90 text-white px-6">
                  <MessageCircle className="h-5 w-5" />
                </Button>
              </div>
            </Card>
          </div>
        </section>

        {/* Onboarding Preview */}
        <section className="container mx-auto px-4 pb-16">
          <div className="max-w-4xl mx-auto">
            <h3 className="font-serif text-2xl font-bold text-sand mb-6 text-center">Onboarding preview</h3>
            <Card className="bg-sand/95 border-sand/50 p-8 shadow-2xl backdrop-blur-sm">
              <p className="text-navy/80 mb-6 text-center leading-relaxed">One question at a time, no extra data.</p>
              <div className="space-y-4">
                {onboardingSteps.map((step, idx) => (
                  <div
                    key={step.id}
                    className={`flex items-center gap-4 p-4 rounded-lg border-2 transition-all animate-fade-in ${
                      step.active ? "border-teal bg-teal/10" : "border-navy/20 bg-white/50"
                    }`}
                    style={{ animationDelay: `${idx * 80}ms` }}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
                        step.active ? "bg-teal text-white" : "bg-navy/20 text-navy/60"
                      }`}
                    >
                      {step.id}
                    </div>
                    <span className={`font-medium ${step.active ? "text-teal" : "text-navy/60"}`}>{step.label}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </section>

        {/* Triage Preview */}
        <section className="container mx-auto px-4 pb-16">
          <div className="max-w-4xl mx-auto">
            <h3 className="font-serif text-2xl font-bold text-sand mb-6 text-center">Triage preview</h3>
            <Card className="bg-sand/95 border-sand/50 p-8 shadow-2xl backdrop-blur-sm">
              <div className="space-y-6">
                {triageFlow.map((item, idx) => (
                  <div key={idx} className="animate-fade-in" style={{ animationDelay: `${idx * 100}ms` }}>
                    <div className="flex items-start gap-4">
                      <div className="w-2 h-2 bg-teal rounded-full mt-2"></div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-navy mb-1">{item.step}</h4>
                        <p className="text-navy/70 leading-relaxed">{item.status}</p>
                      </div>
                    </div>
                    {idx < triageFlow.length - 1 && <div className="ml-1 h-8 w-0.5 bg-teal/30 mt-2"></div>}
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </section>

        {/* Safety Callout */}
        <section className="container mx-auto px-4 pb-16">
          <div className="max-w-4xl mx-auto">
            <Card className="bg-coral/90 border-coral p-6 shadow-2xl backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <AlertCircle className="h-8 w-8 text-white flex-shrink-0" />
                <div>
                  <h3 className="font-serif text-xl font-bold text-white mb-2">Emergency information</h3>
                  <p className="text-white/95 leading-relaxed">
                    If you're in immediate danger, call 999. For urgent advice, use NHS 111.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Useful Links */}
        <section className="container mx-auto px-4 pb-16">
          <div className="max-w-4xl mx-auto">
            <h3 className="font-serif text-2xl font-bold text-sand mb-6 text-center">Useful links</h3>
            <Card className="bg-sand/95 border-sand/50 p-8 shadow-2xl backdrop-blur-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {usefulLinks.map((link, idx) => (
                  <a
                    key={idx}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 rounded-lg border-2 border-navy/20 hover:border-teal hover:bg-teal/5 transition-all group animate-fade-in"
                    style={{ animationDelay: `${idx * 60}ms` }}
                  >
                    <MapPin className="h-5 w-5 text-teal flex-shrink-0" />
                    <span className="text-navy font-medium group-hover:text-teal transition-colors">{link.title}</span>
                    <ChevronRight className="h-4 w-4 text-navy/40 ml-auto group-hover:text-teal transition-colors" />
                  </a>
                ))}
              </div>
            </Card>
          </div>
        </section>

        {/* Footer */}
        <footer className="container mx-auto px-4 pb-12">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Shield className="h-5 w-5 text-sand/60" />
              <p className="text-sand/80 leading-relaxed">
                Evi is informational only and does not provide medical advice.
              </p>
            </div>
            <p className="text-sand/60 text-sm">© 2025 LBS Healthcare Companion</p>
          </div>
        </footer>
      </div>
    </div>
  )
}
